//>>built
define("dijit/nls/hr/loading",({loadingState:"Učitavanje...",errorState:"Žao nam je, došlo je do greške"}));
