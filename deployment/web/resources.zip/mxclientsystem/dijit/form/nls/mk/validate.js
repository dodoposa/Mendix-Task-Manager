//>>built
define("dijit/form/nls/mk/validate",{invalidMessage:"Внесената вредност не е важечка.",missingMessage:"Вредноста е задолжителна.",rangeMessage:"Вредноста е надвор од опсегот."});
